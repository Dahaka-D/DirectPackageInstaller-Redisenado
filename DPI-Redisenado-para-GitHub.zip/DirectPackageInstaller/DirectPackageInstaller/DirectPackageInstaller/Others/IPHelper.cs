﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using DirectPackageInstaller.Views;

namespace DirectPackageInstaller
{
    public static class IPHelper
    {
        public static string[] EnumLocalIPs()
        {
            if (App.IsAndroid && App.GetIPAddresses != null)
            {
                var Ips = App.GetIPAddresses() ?? null;
                if (Ips != null && Ips.Length > 0)
                    return Ips;
            }

            return SearchInterfaces();
        }
        public static string? FindLocalIP(string RemoteIP)
        {
            try
            {
                var IPs = EnumLocalIPs();
                string RemotePartial = RemoteIP.Substring(0, RemoteIP.LastIndexOf('.'));
                return IPs.Single(x => x.StartsWith(RemotePartial));
            }
            catch
            {
                return null;
            }
        }

        static string[] SearchInterfaces()
        {
            List<string> IPs = new List<string>();
            foreach (NetworkInterface Interface in NetworkInterface.GetAllNetworkInterfaces().Where(x => x.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 || x.NetworkInterfaceType == NetworkInterfaceType.Ethernet))
            {
                try
                {
                    foreach (UnicastIPAddressInformation IpInfo in Interface.GetIPProperties().UnicastAddresses.Where(x => x.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork))
                    {
                        try
                        {
                            if (Interface.OperationalStatus != OperationalStatus.Up)
                                continue;

                            if (!IPs.Contains(IpInfo.Address.ToString()))
                                IPs.Add(IpInfo.Address.ToString());
                        }
                        catch { }
                    }
                }
                catch { }
            }

            return IPs.ToArray();
        }

        static HttpClient Client = new HttpClient()
        {
            Timeout = TimeSpan.FromMilliseconds(1000)
        };
        
        
        public static async Task<bool> IsGoldHENOnline(string IP)
        {
            if (!IPAddress.TryParse(IP, out _))
                return false;
            
            var APIUrl = $"http://{IP}:9090/status";
            try
            {
                using var Response = await Client.GetAsync(APIUrl);
                var Resp = await Response.Content.ReadAsStringAsync();
                if (Resp.Replace(" ", "").Contains("\"status\":\"ready\""))
                    return true;
            }
            catch  { }
            return false;
        } 

        public static async Task<bool> IsRPIOnline(string IP)
        {
            if (!IPAddress.TryParse(IP, out _))
                return false;
            
            var APIUrl = $"http://{IP}:12800/api";
            try
            {
                using var Response = await Client.GetAsync(APIUrl);
                var Resp = await Response.Content.ReadAsStringAsync();
                if (Resp.Contains("Unsupported method") && Resp.Contains("fail"))
                    return true;
            }
            catch  { }
            return false;
        }

        public static async Task<bool> IsEtaHenOnline(string IP)
        {
            if (!IPAddress.TryParse(IP, out _))
                return false;

            var APIUrl = $"http://{IP}:12800/";
            try
            {
                using var Response = await Client.GetAsync(APIUrl);
                var Resp = await Response.Content.ReadAsStringAsync();
                if (Resp.Contains("etaHEN"))
                    return true;
            }
            catch { }
            return false;
        }
    }
}
